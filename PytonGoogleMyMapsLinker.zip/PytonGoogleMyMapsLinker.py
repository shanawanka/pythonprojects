import webbrowser
import csv

# Lettura del file CSV dalla AS400
filename = '/path/to/file.csv'  # Inserire il percorso del file CSV sulla AS400
locations = []
with open(filename) as f:
    reader = csv.reader(f)
    for row in reader:
        # Parsing del file CSV e recupero dei dati di localizzazione
        # Assumiamo che il file CSV contenga solo una colonna con indirizzi separati da virgola
        location = '+'.join(row[0].split(','))
        locations.append(location)

# Costruzione dell'URL di Google My Maps
base_url = 'https://www.google.com/maps/d/viewer?mid='
map_id = 'YOUR_MAP_ID_HERE'  # Inserire l'ID della tua mappa personalizzata di Google My Maps
locations_param = '&'.join(locations)
url = f'{base_url}{map_id}&{locations_param}'

# Apertura dell'URL in un browser web
webbrowser.open_new(url)
